import type { Configuration } from './type';
export declare let configuration: Configuration;
export default configuration;
