/// <reference types="node" />
import { Encoding, Mapping, RecursiveEvaluateable } from 'clientnode/type';
import { Configuration, EvaluateablePartialConfiguration, MetaPluginConfiguration, PackageConfiguration, Plugin, PluginChange } from './type';
export declare const currentRequire: NodeRequire;
/**
 * A dumm plugin interface with all available hooks.
 */
export declare class PluginAPI {
    /**
     * Calls all plugin methods for given trigger description asynchronous and
     * waits for their resolved promises.
     * @param this - Nothing.
     * @param hook - Type of trigger.
     * @param plugins - List of plugins to search for trigger callbacks in.
     * @param configuration - Plugin extendable configuration object.
     * @param data - Data to pipe throw all plugins and resolve after all
     * plugins have been resolved.
     * @param parameters - Additional parameters to forward into plugin api.
     *
     * @returns A promise which resolves when all callbacks have resolved their
     * promise holding given potentially modified data.
     */
    static callStack<Input = unknown, Result = unknown>(this: void, hook: string, plugins: Array<Plugin>, configuration: Configuration, data?: Input, ...parameters: Array<unknown>): Promise<Result>;
    /**
     * Calls all plugin methods for given trigger description synchronous.
     * @param this - Nothing.
     * @param hook - Hook to trigger.
     * @param plugins - List of plugins to search for trigger callbacks in.
     * @param configuration - Plugin extendable configuration object.
     * @param data - Data to pipe throw all plugins and resolve after all
     * plugins have been resolved.
     * @param parameters - Additional parameters to forward into plugin api.
     *
     * @returns Given potentially modified data.
     */
    static callStackSynchronous<Input = unknown, Result = unknown>(this: void, hook: string, plugins: Array<Plugin>, configuration: Configuration, data?: Input, ...parameters: Array<unknown>): Result;
    /**
     * Converts given plugin name into the corresponding internal
     * representation.
     * @param this - Nothing.
     * @param name - Name to convert.
     * @param regularExpression - Regular expression pattern which extracts
     * relevant name path as first match group.
     *
     * @returns Transformed name.
     */
    static determineInternalName(this: void, name: string, regularExpression: RegExp): string;
    /**
     * Evaluates given configuration object by letting plugins package sub
     * structure untouched.
     * @param this - Nothing.
     * @param configuration - Evaluateable configuration structure.
     *
     * @returns Resolved configuration.
     */
    static evaluateConfiguration<Type = Configuration>(this: void, configuration: RecursiveEvaluateable<Type> | Type): Type;
    /**
     * Checks for changed plugin api file in given plugins and reloads them
     * if necessary (new timestamp).
     * @param this - Nothing.
     * @param plugins - List of plugins to search for updates in.
     *
     * @returns A list with plugins which have a changed api scope.
     */
    static hotReloadAPIFile(this: void, plugins: Array<Plugin>): Array<Plugin>;
    /**
     * Checks for changed plugin configurations in given plugins and reloads
     * them if necessary (new timestamp).
     * @param this - Nothing.
     * @param plugins - List of plugins to search for updates in.
     * @param configurationPropertyNames - Property names to search for to use
     * as entry in plugin configuration file.
     *
     * @returns A list with plugins which have a changed configurations.
     */
    static hotReloadConfigurationFile(this: void, plugins: Array<Plugin>, configurationPropertyNames: Array<string>): Array<Plugin>;
    /**
     * Checks for changed plugin file type in given plugins and reloads them
     * if necessary (timestamp has changed).
     * @param this - Nothing.
     * @param type - Plugin file type to search for updates.
     * @param target - Property name existing in plugin meta informations
     * objects which should be updated.
     * @param plugins - List of plugins to search for updates in.
     *
     * @returns A list with plugin changes.
     */
    static hotReloadFiles(this: void, type: 'api' | 'configuration', target: 'packageConfiguration' | 'scope', plugins: Array<Plugin>): Array<PluginChange>;
    /**
     * Extends given configuration object with given plugin specific ones and
     * returns a plugin specific meta information object.
     * @param this - Nothing.
     * @param name - Name of plugin to extend.
     * @param internalName - Internal name of plugin to extend.
     * @param plugins - List of all yet determined plugin informations.
     * @param metaConfiguration - Configuration file configuration.
     * @param pluginPath - Path to given plugin.
     * @param encoding - Encoding to use to read and write from child
     * process's.
     *
     * @returns An object of plugin specific meta informations.
     */
    static load(this: void, name: string, internalName: string, plugins: Mapping<Plugin>, metaConfiguration: MetaPluginConfiguration, pluginPath: string, encoding?: Encoding): Promise<Plugin>;
    /**
     * Load given plugin api file in given path and generates a plugin
     * specific data structure with useful meta informations.
     * @param this - Nothing.
     * @param relativeFilePaths - Paths to file to load relatively from given
     * plugin path.
     * @param pluginPath - Path to plugin directory.
     * @param name - Plugin name to use for proper error messages.
     * @param internalName - Internal plugin name to use for proper error
     * messages.
     * @param plugins - List of plugins to search for trigger callbacks in.
     * @param encoding - Encoding to use to read and write from child
     * process.
     * @param configuration - Plugin specific configurations.
     * @param configurationFilePaths - Plugin specific configuration file
     * paths.
     *
     * @returns Plugin meta informations object.
     */
    static loadAPI(this: void, relativeFilePaths: Array<string>, pluginPath: string, name: string, internalName: string, plugins: Mapping<Plugin>, encoding?: Encoding, configuration?: null | EvaluateablePartialConfiguration, configurationFilePaths?: Array<string>): Promise<Plugin>;
    /**
     * Loads plugin specific configuration object.
     * @param this - Nothing.
     * @param name - Property name where to inject resolved configuration into
     * global one.
     * @param packageConfiguration - Plugin specific package configuration
     * object.
     * @param configurationPropertyNames - Property names to search for to use
     * as entry in plugin configuration file.
     *
     * @returns Determined configuration object.
     */
    static loadConfiguration(this: void, name: string, packageConfiguration: PackageConfiguration, configurationPropertyNames: Array<string>): EvaluateablePartialConfiguration;
    /**
     * Loads given plugin configurations into global configuration.
     * @param this - Nothing.
     * @param plugins - Topological sorted list of plugins to check for
     * configurations.
     * @param configuration - Global configuration to extend with.
     *
     * @returns Updated given configuration object.
     */
    static loadConfigurations(this: void, plugins: Array<Plugin>, configuration: Configuration): Configuration;
    /**
     * Load given api file path and returns exported scope.
     * @param this - Nothing.
     * @param filePath - Path to file to load.
     * @param name - Plugin name to use for proper error messages.
     * @param fallbackScope - Scope to return if an error occurs during
     * loading. If a "null" is given an error will be thrown.
     * @param log - Enables logging.
     *
     * @returns Exported api file scope.
     */
    static loadFile(this: void, filePath: string, name: string, fallbackScope?: null | object, log?: boolean): object;
    /**
     * Extends given configuration object with all plugin specific ones and
     * returns a topological sorted list of plugins with plugins specific
     * meta informations stored.
     * @param this - Nothing.
     * @param configuration - Configuration object to extend and use.
     *
     * @returns A topological sorted list of plugins objects.
     */
    static loadAll(this: void, configuration: Configuration): Promise<{
        configuration: Configuration;
        plugins: Array<Plugin>;
    }>;
    /**
     * Transform a list of absolute paths respecting the application context.
     * @param this - Nothing.
     * @param configuration - Configuration object.
     * @param locations - Locations to process.
     *
     * @returns Given and processed locations.
     */
    static determineLocations(this: void, configuration: Configuration, locations?: Array<string> | string): Array<string>;
    /**
     * Ignore absolute defined locations (relativ to application context) and
     * relative defined in each loaded plugin location.
     * @param this - Nothing.
     * @param configuration - Configuration object.
     * @param plugins - List of acctive plugins.
     * @param filePath - Path to search for.
     * @param locations - Locations to search in.
     *
     * @returns A boolean indicating whether given file path is in provided
     * locations.
     */
    static isInLocations(this: void, configuration: Configuration, plugins: Array<Plugin>, filePath: string, locations: Array<string> | string): boolean;
}
export default PluginAPI;
