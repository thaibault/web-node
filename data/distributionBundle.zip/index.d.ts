export * from './configurator';
export * from './pluginAPI';
export declare const main: () => Promise<void>;
export default main;
