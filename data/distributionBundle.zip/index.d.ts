export * from './configurator';
export * from './pluginAPI';
import { Logger } from 'clientnode';
export declare const log: Logger;
export declare const main: () => Promise<void>;
export default main;
