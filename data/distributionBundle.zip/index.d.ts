export * from './configurator';
export * from './pluginAPI';
import { ProcedureFunction } from 'clientnode/type';
export declare const main: ProcedureFunction;
export default main;
